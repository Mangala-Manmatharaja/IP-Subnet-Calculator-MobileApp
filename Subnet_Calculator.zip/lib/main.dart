import 'package:flutter/material.dart';

void main() => runApp(const SubnetApp());

class SubnetApp extends StatelessWidget {
  const SubnetApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'IP Subnet Calculator',
      theme: ThemeData(
        brightness: Brightness.light,
        fontFamily: 'Roboto',
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigoAccent),
        useMaterial3: true,
      ),
      debugShowCheckedModeBanner: false,
      home: const SubnetHomePage(),
    );
  }
}

class SubnetHomePage extends StatefulWidget {
  const SubnetHomePage({super.key});

  @override
  State<SubnetHomePage> createState() => _SubnetHomePageState();
}

class _SubnetHomePageState extends State<SubnetHomePage> {
  final TextEditingController ipController =
      TextEditingController(text: "192.168.1.1");
  double cidr = 24;

  String get subnetMask => _prefixToMask(cidr.toInt());

  String _prefixToMask(int prefix) {
    var mask = List.generate(4, (i) => 0);
    for (int i = 0; i < prefix; i++) {
      mask[i ~/ 8] |= 1 << (7 - (i % 8));
    }
    return mask.join('.');
  }

  String _ipToBinary(String ip) => ip
      .split('.')
      .map((e) => int.parse(e).toRadixString(2).padLeft(8, '0'))
      .join('.');

  String _ipToHex(String ip) => ip
      .split('.')
      .map((e) => int.parse(e).toRadixString(16).padLeft(2, '0'))
      .join('.')
      .toUpperCase();

  String _getIPClass(String ip) {
    final first = int.parse(ip.split('.')[0]);
    if (first < 128) return "Class A (Private)";
    if (first < 192) return "Class B (Private)";
    return "Class C (Private)";
  }

  String _wildcardMask(String mask) {
    return mask
        .split('.')
        .map((e) => (255 - int.parse(e)).toString())
        .join('.');
  }

  @override
  Widget build(BuildContext context) {
    final ip = ipController.text.trim();
    final binary = _ipToBinary(ip);
    final hex = _ipToHex(ip);
    final ipClass = _getIPClass(ip);

    return Scaffold(
      appBar: AppBar(
        title: const Text('IP Subnet Calculator'),
        centerTitle: true,
        backgroundColor: Colors.indigoAccent,
        foregroundColor: Colors.white,
        elevation: 5,
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFe0f7fa), Color(0xFF80deea)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        padding: const EdgeInsets.all(20),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("Enter IPv4 Address",
                  style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                      color: Colors.black87)),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: ipController,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                        prefixIcon:
                            const Icon(Icons.wifi, color: Colors.indigoAccent),
                        filled: true,
                        fillColor: Colors.white,
                        labelText: "e.g. 192.168.1.1",
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide:
                              const BorderSide(color: Colors.indigoAccent),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Text("/${cidr.toInt()}",
                      style: const TextStyle(fontSize: 18)),
                ],
              ),
              Slider(
                value: cidr,
                min: 8,
                max: 30,
                divisions: 22,
                activeColor: Colors.indigoAccent,
                label: "/${cidr.toInt()}",
                onChanged: (value) => setState(() => cidr = value),
              ),
              Text("Subnet Mask: $subnetMask",
                  style: const TextStyle(fontWeight: FontWeight.w500)),
              const SizedBox(height: 20),
              _buildCard("IP Address Info", [
                "IP Address: $ip",
                "Hexadecimal: $hex",
                "Binary: $binary",
              ]),
              const SizedBox(height: 16),
              _buildCard("Network Details", [
                "Class: $ipClass",
                "CIDR: /${cidr.toInt()}",
                "Subnet Mask: $subnetMask",
                "Wildcard Mask: ${_wildcardMask(subnetMask)}",
              ]),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCard(String title, List<String> lines) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 10,
            offset: Offset(2, 4),
          ),
        ],
        color: Colors.white,
      ),
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                  color: Colors.indigoAccent)),
          const SizedBox(height: 12),
          ...lines.map((line) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Text(line,
                    style:
                        const TextStyle(fontSize: 16, color: Colors.black87)),
              )),
        ],
      ),
    );
  }
}
